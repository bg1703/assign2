// modEncrypt.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodEncrypt)
//}}ChodeBot_Includes

#include "modEncrypt.h"

void SetEncKey()
{
}

CString EnDeCrypt(CString& plaintxt)
{
	CString EnDeCrypt = "?";
	return EnDeCrypt;
}



void DecipherBArray(BYTE* bArray, int& lngnum)
{
}

CString yEncode(CString& sString)
{
	CString yEncode = "?";
	return yEncode;
}

CString yDecode(CString& sString)
{
	CString yDecode = "?";
	return yDecode;
}

CString SCODecipherStr(CString& sString)
{
	CString SCODecipherStr = "?";
	return SCODecipherStr;
}
