#!/usr/bin/env groovy
package com.anchorfree;

class JenkinsTools {

    def JenkinsTools () {
        sleep(0)
    }

    def silentSleep(Integer time) {
        sleep(time*1000)
    }

}
