package pyxis.uzuki.live.richutilskt.impl;

public interface F11<A, B, C, D, E, F, G, H, I, J, K> {
    void invoke(A object, B object1, C object2, D object3, E object4, F object5, G object6, H object7, I object8, J object9, K object10);
}